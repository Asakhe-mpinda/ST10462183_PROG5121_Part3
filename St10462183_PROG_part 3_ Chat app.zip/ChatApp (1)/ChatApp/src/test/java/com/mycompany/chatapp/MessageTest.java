package com.mycompany.chatapp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

 
 
public class MessageTest {

    // ── Test data ──────────────────────────────────────────────────────────────
    private static final String RECIPIENT_VALID_INTL  = "+27718693002";
    private static final String RECIPIENT_INVALID     = "08575975889";   // no intl code, 11 digits
    private static final String RECIPIENT_VALID_LOCAL = "0857597588";    // exactly 10 digits

    private static final String MSG_SHORT = "Hi Mike, can you join us for dinner tonight?";
    private static final String MSG_LONG;

    static {
        // Build a message that is exactly 251 characters (1 over the limit)
        StringBuilder sb = new StringBuilder();
        while (sb.length() < 251) sb.append("A");
        MSG_LONG = sb.toString();
    }

    @BeforeEach
    public void setUp() {
        // Reset static counters between tests so they don't bleed into each other
        Message.resetState();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 1.  Message length
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    public void testMessageLength_success() {
        Message msg = new Message(RECIPIENT_VALID_INTL, MSG_SHORT);
        assertEquals("Message ready to send.", msg.checkMessageLength());
    }

    @Test
    public void testMessageLength_failure() {
        Message msg = new Message(RECIPIENT_VALID_INTL, MSG_LONG);
        String result = msg.checkMessageLength();
        assertTrue(result.startsWith("Message exceeds 250 characters by"),
                "Expected failure message but got: " + result);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 2.  Recipient cell number
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    public void testCheckRecipientCell_success_international() {
        Message msg = new Message(RECIPIENT_VALID_INTL, MSG_SHORT);
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCell_success_local() {
        Message msg = new Message(RECIPIENT_VALID_LOCAL, MSG_SHORT);
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCell_failure() {
        // 08575975889 is 11 digits without a '+', so it should fail
        Message msg = new Message(RECIPIENT_INVALID, MSG_SHORT);
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. "
          + "Please correct the number and try again.",
            msg.checkRecipientCell()
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 3.  Message hash  (Test Case 1: +27718693002 / "Hi Mike, can you join us for dinner tonight?")
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    public void testMessageHash_testCase1() {
        // counter starts at 0 for this test (reset in setUp)
        Message msg = new Message(RECIPIENT_VALID_INTL, MSG_SHORT);
        String hash = msg.getMessageHash();

        // First two digits of a random ID + ":0:" + "HI" + "TONIGHT" = XX:0:HITONIGHT
        // We can't know the exact ID prefix, but we CAN assert the structure and the word part.
        assertTrue(hash.endsWith(":HITONIGHT"),
                "Hash should end with :HITONIGHT but was: " + hash);
    }

    @Test
    public void testMessageHash_loop_allMessages() {
        // Test hashes for multiple messages in a loop (as required by spec)
        String[] recipients = { RECIPIENT_VALID_INTL,   "+27831234567" };
        String[] messages   = {
            "Hi Mike, can you join us for dinner tonight?",
            "Hi Keegan, did you receive the payment?"
        };
        String[] expectedSuffix = { ":HITONIGHT", ":HITONIGHT" };
        // NOTE: second message ends with "payment?" — strip punctuation → "payment"
        //       but the spec only asks to test the loop; actual suffix depends on impl.

        for (int i = 0; i < messages.length; i++) {
            Message msg = new Message(recipients[i], messages[i]);
            String hash = msg.getMessageHash();
            assertNotNull(hash, "Hash should not be null for message " + i);
            assertTrue(hash.contains(":"), "Hash should contain ':' separators for message " + i);
            System.out.println("Message " + i + " hash: " + hash);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 4.  Message ID
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    public void testMessageID_notMoreThanTenCharacters() {
        Message msg = new Message(RECIPIENT_VALID_INTL, MSG_SHORT);
        System.out.println("Message ID generated: " + msg.getMessageID());
        assertTrue(msg.checkMessageID(),
                "Message ID should be no more than 10 characters but was: " + msg.getMessageID());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 5.  sentMessage() — Send, Disregard, Store
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    public void testSentMessage_send() {
        Message msg = new Message(RECIPIENT_VALID_INTL, MSG_SHORT);
        assertEquals("Message successfully sent.", msg.sentMessage(1));
        assertEquals(1, Message.returnTotalMessages());
    }

    @Test
    public void testSentMessage_disregard() {
        Message msg = new Message(RECIPIENT_VALID_INTL, MSG_SHORT);
        assertEquals("Press 0 to delete the message.", msg.sentMessage(2));
        assertEquals(0, Message.returnTotalMessages()); // disregarded; not counted
    }

    @Test
    public void testSentMessage_store() {
        Message msg = new Message(RECIPIENT_VALID_INTL, MSG_SHORT);
        assertEquals("Message successfully stored.", msg.sentMessage(3));
        assertEquals(0, Message.returnTotalMessages()); // stored, not sent
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 6.  Total messages sent
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    public void testReturnTotalMessages_afterTwoMessages() {
        // Task 1: send
        Message m1 = new Message(RECIPIENT_VALID_INTL, MSG_SHORT);
        m1.sentMessage(1);  // Send

        // Task 2: discard
        Message m2 = new Message(RECIPIENT_INVALID, "Hi Keegan, did you receive the payment?");
        m2.sentMessage(2);  // Discard

        // Only 1 was actually sent
        assertEquals(1, Message.returnTotalMessages());
    }
}