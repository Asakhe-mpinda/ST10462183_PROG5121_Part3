package com.mycompany.chatapp;

import java.util.regex.Pattern;

public class Login {

    private String username;         // Stores the username of the user
    private String password;         // Stores the password of the user
    private String cellPhoneNumber;  // Stores the cell phone number of the user
    private String firstName;        // Stores the first name of the user
    private String lastName;         // Stores the last name of the user

    // USERNAME 
    /**
     * Checks if the username contains an underscore and has a length of 5 or fewer characters.
     * @param username the username to be checked
     * @return true if the username contains an underscore and has a length <= 5, false otherwise
     */
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    /**
     * Registers a username if it is valid, otherwise returns an error message.
     * @param username the username to be registered
     * @return a message indicating whether the username was successfully captured or not
     */
    public String registerUserName(String username) {
        if (checkUserName(username)) {
            this.username = username;
            return "Username successfully captured.";
        } else {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
    }

    //  PASSWORD 
    /**
     * Checks the password complexity using a regular expression. The password must contain:
     * - At least one uppercase letter
     * - At least one digit
     * - At least one special character
     * - A length of at least 8 characters
     * @param password the password to be checked
     * @return true if the password meets the complexity requirements, false otherwise
     */
    public boolean checkPasswordComplexity(String password) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}$";
        return Pattern.matches(regex, password);
    }

    /**
     * Registers a password if it meets the complexity requirements, otherwise returns an error message.
     * @param password the password to be registered
     * @return a message indicating whether the password was successfully captured or not
     */
    public String registerPassword(String password) {
        if (checkPasswordComplexity(password)) {
            this.password = password;
            return "Password successfully captured.";
        } else {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
    }

    // CELL PHONE 
    /**
     * Checks if the cell phone number is valid. The number must start with a '+' followed by a country code and a maximum of 10 digits.
     * @param cellPhoneNumber the phone number to be checked
     * @return true if the phone number matches the format, false otherwise
     */
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        // Must start with + and include country code, total digits after + max 10
        String regex = "^\\+\\d{1,3}\\d{1,10}$";
        return Pattern.matches(regex, cellPhoneNumber);
    }

    /**
     * Registers a cell phone number if it is valid, otherwise returns an error message.
     * @param cellPhoneNumber the phone number to be registered
     * @return a message indicating whether the phone number was successfully added or not
     */
    public String registerCellPhoneNumber(String cellPhoneNumber) {
        if (checkCellPhoneNumber(cellPhoneNumber)) {
            this.cellPhoneNumber = cellPhoneNumber;
            return "Cell phone number successfully added.";
        } else {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
    }

    //  REGISTER USER (REQUIRED METHOD) 
    /**
     * Registers a user with a valid username and password.
     * @param username the username to be registered
     * @param password the password to be registered
     * @return a message indicating whether the user was successfully registered or not
     */
    public String registerUser(String username, String password) {
        // Check if the username and password meet the requirements
        if (!checkUserName(username)) {
            return "The username is incorrectly formatted.";
        }

        if (!checkPasswordComplexity(password)) {
            return "The password does not meet the complexity requirements.";
        }

        // Store the username and password only if both are valid
        this.username = username;
        this.password = password;

        return "The two above conditions have been met, and the user has been registered successfully.";
    }

    //  USER DETAILS 
    /**
     * Sets the first name of the user.
     * @param firstName the first name of the user
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Sets the last name of the user.
     * @param lastName the last name of the user
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // LOGIN 
    /**
     * Attempts to log in a user by comparing the provided username and password with stored values.
     * @param username the username to be checked
     * @param password the password to be checked
     * @return true if the username and password match the stored values, false otherwise
     */
    public boolean loginUser(String username, String password) {
        return this.username != null &&
               this.password != null &&
               this.username.equals(username) &&
               this.password.equals(password);
    }

    /**
     * Returns a status message after attempting login.
     * If the login is successful, it returns a welcome message with the user's full name.
     * If the login fails, it returns an error message.
     * @param username the username to be checked
     * @param password the password to be checked
     * @return a message indicating login success or failure
     */
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
