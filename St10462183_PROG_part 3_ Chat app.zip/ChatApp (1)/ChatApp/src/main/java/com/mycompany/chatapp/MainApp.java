package com.mycompany.chatapp;

import java.io.*;
import java.util.*;

public class MainApp {

    // ── In-memory arrays (populated at runtime, no hard-coding) ──────────────
    private static final List<Message> sentMessagesArr        = new ArrayList<>();
    private static final List<Message> disregardedMessagesArr = new ArrayList<>();
    private static final List<Message> storedMessagesArr      = new ArrayList<>();
    private static final List<String>  messageHashesArr       = new ArrayList<>();
    private static final List<String>  messageIDsArr          = new ArrayList<>();

    private static final String STORED_FILE = "stored_messages.json";

    // ── Sender cell (captured during registration, used in reports) ───────────
    private static String senderCell = "";

    public static void main(String[] args) {

        try (Scanner input = new Scanner(System.in)) {
            Login login = new Login();

            // ── User details ──────────────────────────────────────────────────
            System.out.print("Enter first name: ");
            String firstName = input.nextLine();

            System.out.print("Enter last name: ");
            String lastName = input.nextLine();

            login.setFirstName(firstName);
            login.setLastName(lastName);

            // ── Username registration loop ────────────────────────────────────
            String username;
            do {
                System.out.print("Enter username (max 5 chars, must contain '_'): ");
                username = input.nextLine();
                System.out.println(login.registerUserName(username));
            } while (!login.checkUserName(username));

            // ── Password registration loop ────────────────────────────────────
            String password;
            do {
                System.out.print("Enter password: ");
                password = input.nextLine();
                System.out.println(login.registerPassword(password));
            } while (!login.checkPasswordComplexity(password));

            // ── Cell-phone registration loop ──────────────────────────────────
            String cell;
            do {
                System.out.print("Enter cell phone number (e.g. +27718693002): ");
                cell = input.nextLine();
                System.out.println(login.registerCellPhoneNumber(cell));
            } while (!login.checkCellPhoneNumber(cell));
            senderCell = cell;

            // ── Login ─────────────────────────────────────────────────────────
            System.out.println("\n--- LOGIN ---");
            boolean loggedIn = false;
            while (!loggedIn) {
                System.out.print("Enter username: ");
                String loginUser = input.nextLine();
                System.out.print("Enter password: ");
                String loginPass = input.nextLine();
                String loginStatus = login.returnLoginStatus(loginUser, loginPass);
                System.out.println(loginStatus);
                loggedIn = login.loginUser(loginUser, loginPass);
            }

            // Load any previously stored messages from JSON file
            loadStoredMessagesFromFile();

            // ── Main menu ─────────────────────────────────────────────────────
            System.out.println("\nWelcome to QuickChat.");
            boolean running = true;
            while (running) {
                System.out.println("\n--- MENU ---");
                System.out.println("1) Send Messages");
                System.out.println("2) Show recently sent messages");
                System.out.println("3) Stored Messages");
                System.out.println("4) Quit");
                System.out.print("Choose an option: ");

                String menuChoice = input.nextLine().trim();

                switch (menuChoice) {
                    case "1" -> handleSendMessage(input);
                    case "2" -> showRecentlySentMessages();
                    case "3" -> handleStoredMessagesMenu(input);
                    case "4" -> {
                        System.out.println("Total messages sent: " + Message.returnTotalMessages());
                        System.out.println("Goodbye!");
                        running = false;
                    }
                    default -> System.out.println("Invalid choice. Please enter 1, 2, 3, or 4.");
                }
            }
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    //  SEND MESSAGE FLOW
    // ────────────────────────────────────────────────────────────────────────
    private static void handleSendMessage(Scanner input) {

        // Recipient
        String recipient = null;
        Message tempMsg;
        do {
            System.out.print("Enter recipient cell number: ");
            String entered = input.nextLine();
            tempMsg = new Message(entered, "");
            String cellCheck = tempMsg.checkRecipientCell();
            System.out.println(cellCheck);
            if (cellCheck.equals("Cell phone number successfully captured.")) {
                recipient = entered;
            }
        } while (recipient == null);

        // Message text
        String messageText = null;
        Message message = null;
        do {
            System.out.print("Enter your message (max 250 characters): ");
            String entered = input.nextLine();
            message = new Message(recipient, entered);
            String lengthCheck = message.checkMessageLength();
            System.out.println(lengthCheck);
            if (lengthCheck.equals("Message ready to send.")) {
                messageText = entered;
            }
        } while (messageText == null);

        System.out.println("\nMessage ID generated: " + message.getMessageID());
        System.out.println("Message Hash        : " + message.getMessageHash());

        // Action choice
        int actionChoice = 0;
        while (actionChoice == 0) {
            System.out.println("\nWhat would you like to do?");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            System.out.print("Choose an option: ");

            String choiceStr = input.nextLine().trim();
            try {
                int parsed = Integer.parseInt(choiceStr);
                if (parsed >= 1 && parsed <= 3) {
                    String result = message.sentMessage(parsed);
                    System.out.println(result);

                    // Track in arrays
                    messageIDsArr.add(message.getMessageID());
                    messageHashesArr.add(message.getMessageHash());

                    switch (parsed) {
                        case 1 -> {
                            sentMessagesArr.add(message);
                            System.out.println("\n--- Message Details ---");
                            System.out.println("Message ID   : " + message.getMessageID());
                            System.out.println("Message Hash : " + message.getMessageHash());
                            System.out.println("Recipient    : " + message.getRecipientCell());
                            System.out.println("Message      : " + message.getMessageText());
                        }
                        case 2 -> disregardedMessagesArr.add(message);
                        case 3 -> {
                            storedMessagesArr.add(message);
                            saveStoredMessagesToFile();
                        }
                    }
                    actionChoice = parsed;
                } else {
                    System.out.println("Please enter 1, 2, or 3.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number (1, 2, or 3).");
            }
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    //  SHOW RECENTLY SENT MESSAGES
    // ────────────────────────────────────────────────────────────────────────
    private static void showRecentlySentMessages() {
        if (sentMessagesArr.isEmpty()) {
            System.out.println("No messages sent yet.");
            return;
        }
        System.out.println("\n===== Recently Sent Messages =====");
        for (Message m : sentMessagesArr) {
            System.out.println("ID      : " + m.getMessageID());
            System.out.println("Hash    : " + m.getMessageHash());
            System.out.println("To      : " + m.getRecipientCell());
            System.out.println("Message : " + m.getMessageText());
            System.out.println("----------------------------------");
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    //  STORED MESSAGES MENU  (requirement 2a-f)
    // ────────────────────────────────────────────────────────────────────────
    private static void handleStoredMessagesMenu(Scanner input) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- STORED MESSAGES MENU ---");
            System.out.println("a) Display sender and recipient of all stored messages");
            System.out.println("b) Display the longest stored message");
            System.out.println("c) Search by message ID");
            System.out.println("d) Search by recipient");
            System.out.println("e) Delete a message using message hash");
            System.out.println("f) Display full report of all stored messages");
            System.out.println("0) Back to main menu");
            System.out.print("Choose an option: ");

            String choice = input.nextLine().trim().toLowerCase();

            switch (choice) {
                case "a" -> displayStoredSenderRecipient();
                case "b" -> displayLongestStoredMessage();
                case "c" -> searchByMessageID(input);
                case "d" -> searchByRecipient(input);
                case "e" -> deleteByHash(input);
                case "f" -> displayFullStoredReport();
                case "0" -> back = true;
                default  -> System.out.println("Invalid choice.");
            }
        }
    }

    // a) Sender and recipient of all stored messages
    private static void displayStoredSenderRecipient() {
        if (storedMessagesArr.isEmpty()) {
            System.out.println("No stored messages.");
            return;
        }
        System.out.println("\n===== Stored Messages – Sender & Recipient =====");
        for (Message m : storedMessagesArr) {
            System.out.println("Sender    : " + senderCell);
            System.out.println("Recipient : " + m.getRecipientCell());
            System.out.println("------------------------------------------------");
        }
    }

    // b) Longest stored message
    private static void displayLongestStoredMessage() {
        if (storedMessagesArr.isEmpty()) {
            System.out.println("No stored messages.");
            return;
        }
        Message longest = storedMessagesArr.stream()
                .max(Comparator.comparingInt(m -> m.getMessageText().length()))
                .orElse(null);
        if (longest != null) {
            System.out.println("\nLongest Stored Message:");
            System.out.println("ID      : " + longest.getMessageID());
            System.out.println("Hash    : " + longest.getMessageHash());
            System.out.println("To      : " + longest.getRecipientCell());
            System.out.println("Message : " + longest.getMessageText());
            System.out.println("Length  : " + longest.getMessageText().length() + " characters");
        }
    }

    // c) Search by message ID
    private static void searchByMessageID(Scanner input) {
        System.out.print("Enter message ID to search: ");
        String searchID = input.nextLine().trim();
        boolean found = false;
        for (Message m : storedMessagesArr) {
            if (m.getMessageID().equals(searchID)) {
                System.out.println("\nMatch found:");
                System.out.println("Recipient : " + m.getRecipientCell());
                System.out.println("Message   : " + m.getMessageText());
                found = true;
            }
        }
        if (!found) System.out.println("No stored message found with ID: " + searchID);
    }

    // d) Search by recipient
    private static void searchByRecipient(Scanner input) {
        System.out.print("Enter recipient cell number to search: ");
        String searchCell = input.nextLine().trim();
        boolean found = false;
        System.out.println("\nMessages stored for " + searchCell + ":");
        for (Message m : storedMessagesArr) {
            if (m.getRecipientCell().equals(searchCell)) {
                System.out.println("  ID      : " + m.getMessageID());
                System.out.println("  Message : " + m.getMessageText());
                System.out.println("  --------");
                found = true;
            }
        }
        if (!found) System.out.println("No stored messages found for recipient: " + searchCell);
    }

    // e) Delete by hash
    private static void deleteByHash(Scanner input) {
        System.out.print("Enter message hash to delete: ");
        String hash = input.nextLine().trim();
        boolean removed = storedMessagesArr.removeIf(m -> m.getMessageHash().equalsIgnoreCase(hash));
        if (removed) {
            System.out.println("Message with hash '" + hash + "' deleted successfully.");
            saveStoredMessagesToFile();   // keep JSON in sync
        } else {
            System.out.println("No stored message found with hash: " + hash);
        }
    }

    // f) Full report of all stored messages
    private static void displayFullStoredReport() {
        if (storedMessagesArr.isEmpty()) {
            System.out.println("No stored messages.");
            return;
        }
        System.out.println("\n========== Full Stored Messages Report ==========");
        for (int i = 0; i < storedMessagesArr.size(); i++) {
            Message m = storedMessagesArr.get(i);
            System.out.println("Record    : " + (i + 1));
            System.out.println("ID        : " + m.getMessageID());
            System.out.println("Hash      : " + m.getMessageHash());
            System.out.println("Sender    : " + senderCell);
            System.out.println("Recipient : " + m.getRecipientCell());
            System.out.println("Message   : " + m.getMessageText());
            System.out.println("Status    : " + m.getStatus());
            System.out.println("-------------------------------------------------");
        }
        System.out.println("Total stored messages: " + storedMessagesArr.size());
    }

    // ────────────────────────────────────────────────────────────────────────
    //  JSON PERSISTENCE  (org.json.simple)
    // ────────────────────────────────────────────────────────────────────────
    @SuppressWarnings("unchecked")
    private static void saveStoredMessagesToFile() {
        // Persist stored messages as escaped '|' separated lines to avoid JSON library dependency
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(STORED_FILE))) {
            for (Message m : storedMessagesArr) {
                String line = escape(m.getMessageID()) + "|" +
                              escape(m.getMessageHash()) + "|" +
                              escape(senderCell) + "|" +
                              escape(m.getRecipientCell()) + "|" +
                              escape(m.getMessageText()) + "|" +
                              escape(m.getStatus());
                bw.write(line);
                bw.newLine();
            }
            System.out.println("[Info] Stored messages saved to " + STORED_FILE);
        } catch (IOException e) {
            System.out.println("[Warning] Could not save stored messages: " + e.getMessage());
        }
    }

    // Helper: escape backslashes and separator
    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("|", "\\|");
    }

    // Helper: unescape sequences
    private static String unescape(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                sb.append(s.charAt(i + 1));
                i++;
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    // Helper: split a line on unescaped '|' characters
    private static List<String> splitEscaped(String line) {
        List<String> parts = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '\\' && i + 1 < line.length()) {
                sb.append(line.charAt(i + 1));
                i++;
            } else if (c == '|') {
                parts.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(c);
            }
        }
        parts.add(sb.toString());
        return parts;
    }

    private static void loadStoredMessagesFromFile() {
        File file = new File(STORED_FILE);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                List<String> parts = splitEscaped(line);
                if (parts.size() < 6) continue; // expected: id|hash|sender|recipient|text|status
                String recipient = unescape(parts.get(3));
                String text = unescape(parts.get(4));
                Message m = new Message(recipient, text);
                // Restore arrays
                storedMessagesArr.add(m);
                messageIDsArr.add(m.getMessageID());
                messageHashesArr.add(m.getMessageHash());
            }
            if (!storedMessagesArr.isEmpty()) {
                System.out.println("[Info] Loaded " + storedMessagesArr.size()
                        + " stored message(s) from " + STORED_FILE);
            }
        } catch (Exception e) {
            System.out.println("[Warning] Could not load stored messages: " + e.getMessage());
        }
    }
}