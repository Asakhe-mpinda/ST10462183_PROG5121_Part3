package com.mycompany.chatapp;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Message {

    private String messageID;
    private String recipientCell;
    private String messageText;
    private String messageHash;
    private String status; // "Sent", "Stored", "Disregarded"

    // Stores all sent messages across all instances
    private static List<Message> sentMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;
    private static int messageCounter = 0;  // increments for each message created

    // ── Constructor ──────────────────────────────────────────────────────────
    public Message(String recipientCell, String messageText) {
        this.recipientCell = recipientCell;
        this.messageText   = messageText;
        this.messageID     = generateMessageID();
        this.messageHash   = createMessageHash();
    }

    // ── ID generation ────────────────────────────────────────────────────────
    /**
     * Generates a random numeric message ID that is no more than 10 characters.
     */
    private String generateMessageID() {
        Random rand = new Random();
        // Zero-pad to ensure consistent formatting; keep to max 10 chars
        int id = rand.nextInt(90000000 > Integer.MAX_VALUE
                ? Integer.MAX_VALUE : 90000000) + 100000000;   // 9-digit number
        return String.valueOf(id);
    }

    /**
     * Checks that the message ID is not more than 10 characters.
     * @return true if valid
     */
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    // ── Recipient validation ─────────────────────────────────────────────────
    /**
     * Validates the recipient cell number:
     * - Must start with '+' (international code) OR be exactly 10 digits (local SA number).
     * - No more than 13 characters total (e.g. +27718693002 = 12 chars).
     */
    public String checkRecipientCell() {
        if (recipientCell == null) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. "
                 + "Please correct the number and try again.";
        }

        boolean validInternational = recipientCell.matches("^\\+\\d{1,12}$")
                                     && recipientCell.length() <= 13;
        boolean validLocal         = recipientCell.matches("^\\d{10}$");

        if (validInternational || validLocal) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. "
                 + "Please correct the number and try again.";
        }
    }

    // ── Message-length validation ────────────────────────────────────────────
    /**
     * Checks that the message is no longer than 250 characters.
     * @return "Message ready to send." or an error with the excess character count.
     */
    public String checkMessageLength() {
        if (messageText == null) {
            return "Message exceeds 250 characters by 0 characters; please reduce the size.";
        }
        int len = messageText.length();
        if (len <= 250) {
            return "Message ready to send.";
        } else {
            int excess = len - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
    }

    // ── Hash ─────────────────────────────────────────────────────────────────
    /**
     * Creates the message hash in the format:
     *   <first two digits of messageID>:<messageCounter>:<FIRST_WORD><LAST_WORD>
     * All upper-case.  Example: 00:0:HITHANKS
     */
    public String createMessageHash() {
        String idPart      = (messageID != null && messageID.length() >= 2)
                             ? messageID.substring(0, 2)
                             : "00";
        String counterPart = String.valueOf(messageCounter);

        String firstWord = "";
        String lastWord  = "";

        if (messageText != null && !messageText.trim().isEmpty()) {
            String[] words = messageText.trim().split("\\s+");
            firstWord = words[0];
            lastWord  = words[words.length - 1];
        }

        // Strip trailing punctuation from last word for cleaner hash
        lastWord = lastWord.replaceAll("[^A-Za-z0-9]", "");

        return (idPart + ":" + counterPart + ":" + firstWord + lastWord).toUpperCase();
    }

    // ── Send / Store / Disregard ─────────────────────────────────────────────
    /**
     * Processes the user's choice: 1 = Send, 2 = Disregard, 3 = Store.
     * @param choice 1, 2, or 3
     * @return status message
     */
    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                this.status = "Sent";
                sentMessages.add(this);
                totalMessagesSent++;
                messageCounter++;
                return "Message successfully sent.";
            case 2:
                this.status = "Disregarded";
                return "Press 0 to delete the message.";
            case 3:
                this.status = "Stored";
                messageCounter++;
                return "Message successfully stored.";
            default:
                return "Invalid option. Please enter 1, 2, or 3.";
        }
    }

    // ── Display & stats ──────────────────────────────────────────────────────
    /**
     * Returns a formatted string of all messages sent during this session.
     */
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("\n===== Sent Messages =====\n");
        for (Message m : sentMessages) {
            sb.append("Message ID   : ").append(m.messageID).append("\n");
            sb.append("Message Hash : ").append(m.messageHash).append("\n");
            sb.append("Recipient    : ").append(m.recipientCell).append("\n");
            sb.append("Message      : ").append(m.messageText).append("\n");
            sb.append("-------------------------\n");
        }
        return sb.toString();
    }

    /**
     * Returns the total number of messages successfully sent (not stored/disregarded).
     */
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    // ── Getters (needed by tests) ─────────────────────────────────────────────
    public String getMessageID()   { return messageID;   }
    public String getMessageHash() { return messageHash; }
    public String getRecipientCell() { return recipientCell; }
    public String getMessageText()  { return messageText;  }
    public String getStatus()       { return status;       }

    public static List<Message> getSentMessages() { return sentMessages; }

    /** Resets static state — used between unit tests. */
    public static void resetState() {
        sentMessages.clear();
        totalMessagesSent = 0;
        messageCounter    = 0;
    }
}